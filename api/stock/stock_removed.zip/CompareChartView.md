# CompareChartView
> **Extends**: ``



<br/>

## Properties

### frwName



* **Type**: ``
* **Default**: ``

<br/>

### delegator



* **Type**: ``
* **Default**: ``

<br/>

### noReal



* **Type**: ``
* **Default**: ``

<br/>

### compareArray



* **Type**: ``
* **Default**: ``

<br/>

### compareChecks



* **Type**: ``
* **Default**: ``

<br/>

### isInit



* **Type**: ``
* **Default**: ``

<br/>

### sendIdx



* **Type**: ``
* **Default**: ``

<br/>

## Method

### onChartInit()



* **Parameters**: 


* **Usage**: 
```js

```

<br/>

### loadData()



* **Parameters**: 


* **Usage**: 
```js

```

<br/>

### saveData()



* **Parameters**: 


* **Usage**: 
```js

```

<br/>

### setCompareData()



* **Parameters**: 


* **Usage**: 
```js

```

<br/>

### onCompareDataRequest()



* **Parameters**: 


* **Usage**: 
```js

```

<br/>

### getComparePopupData()



* **Parameters**: 


* **Usage**: 
```js

```

<br/>

### setCompareArrayFromPopup()



* **Parameters**: 


* **Usage**: 
```js

```

<br/>

### onComparePopupData()



* **Parameters**: 


* **Usage**: 
```js

```

<br/>

### setCheckCompareItem()



* **Parameters**: 


* **Usage**: 
```js

```

<br/>

### setRemoveCompareItem()



* **Parameters**: 


* **Usage**: 
```js

```

<br/>

### sendArrayDataProcess()



* **Parameters**: 


* **Usage**: 
```js

```

<br/>

### setTimeZone()



* **Parameters**: 


* **Usage**: 
```js

```

<br/>

### onScrollEnd()



* **Parameters**: 


* **Usage**: 
```js

```

<br/>

### onRequestData()



* **Parameters**: 


* **Usage**: 
```js

```

<br/>

### setData()



* **Parameters**: 


* **Usage**: 
```js

```

<br/>

### setQueryData()



* **Parameters**: 


* **Usage**: 
```js

```

<br/>

### onWindowResult()



* **Parameters**: 


* **Usage**: 
```js

```

<br/>